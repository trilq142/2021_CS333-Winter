// halt the system.
#include "types.h"
#include "user.h"
#include "pdx.h"

int
main(void) {
  halt();
  exit();
}
